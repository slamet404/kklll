#!/usr/bin/env python

flag = ""
for i in xrange(345):
    path = "pesan/pesan{}".format(i)
    with open(path, "r") as f:
        binary = f.read()
        operator = binary[0xca]
        key = binary[0xcb]
        check = binary[0xce]

        if operator == "\xc2": 
            flag += chr((ord(check) - ord(key)) & 0xff)

        elif operator == "\xea": 
            flag += chr((ord(check) + ord(key)) & 0xff)

        else:
            flag += chr(ord(check) ^ ord(key))

print flag
