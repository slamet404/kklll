#!/usr/bin/env python

from pwn import *
from random import *

text = """
Sopo sing kuat nandhang kahanan Sopo seng ora kroso kelangan Ditinggal pas sayang sayange Pas lagi jeru jerune, koe milih dalan liyane Sopo sing kuat ditinggal lungo Sopo sing atine ora loro Kenangan sing wis tak lakoni Tak simpen ning njero ati Dewe wes ra dadi siji Yowes ben tak lakoni nganti sak kuat-kuate ati Pesenku mung siji, CTF{enkry1pt10N_y3ahhhh} sing ngati-ati Isoku mung mendem esuk tekan sonten Mergo sadar diri kulo, dudu sinten sinten Yowes ben mung tak pendem roso sing ono ing njero dodo Tetep tak dongakno mugo urip mulyo.
"""

context(arch='amd64')

for i, c in enumerate(text):
    operator = ["xor", "sub", "add"][randint(0, 2)]
    key = randint(1, 100)

    if operator == "xor":
        check = (ord(c) ^ key) & 0xff

    if operator == "sub":
        check = (ord(c) - key) & 0xff

    if operator == "add":
        check = (ord(c) + key) & 0xff

    code = """
		push 0
		push 5
		mov rdi, rsp
		mov rax, 0x23
		syscall
		pop rax
		pop rax
		mov rax, [rsp + 0x10]
		mov dl, byte ptr [rax]
                {} dl, {}
		cmp dl, {}
		jne error
		mov rdi, 0
		mov rax, 0x3c
		syscall
		error:
			mov rdi, 1
			mov rax, 0x3c
			syscall
	""".format(operator, key, check)

    with open("pesan/pesan{}".format(i), "w") as f:
        elf = make_elf(asm(code))
        f.write(elf)
