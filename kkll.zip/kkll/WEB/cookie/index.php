<?php
	if (!isset($_COOKIE["passadmin"]))
		setcookie("passadmin", "KKSICooki3");
	
	if (!isset($_COOKIE["cookiex"]))
		setcookie("cookiex", "WlhsS2NGcERTVFpKYWtWNlRYcGphVXhEU2pCbFdFSnNTV3B2YVZvelZteGpNMUZwWmxFOVBR");
?>

<style>
body {
  background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTjLx3faTAxxmr_qV_1wOIJfio_apqqgYAxMukpMekJkCXD0p8z');
  background-size: cover;
}

h1 {
	font-family: 'Charm', cursive; margin-top: 20px; margin-left:40px; font-size: 50px
}

.wrong {
	color: #FF4242;
	text-shadow: 2px 2px #000000;
}

.right {
	color: #42FF42;
	text-shadow: 2px 2px #000000;
}
</style>

<head>
<link href="https://fonts.googleapis.com/css?family=Charm" rel="stylesheet">
</head>

<body><center>
<h1 style="text-arial: 2px 2px #FFFFFF;">Cookie uenakk rasane rek!</h1>
<img style="margin-top:-20px" src="https://lh3.googleusercontent.com/SoPJ3Fi7DxPpviGo0mjnZo85merX-fyGaHUaY8LwLQ7bIhqeSFm6K9Dh7fWdGAOOBWDPEVY4I8A=w128-h128-e365">
<center></body>

<?php
    error_reporting(0);
	$pass = "..,,,**&&^%%KKSI2019;;;pass";
    $cookie_name = "cookiex";
	
    if (isset($_COOKIE["cookiex"])) {
        $val = json_decode(base64_decode(base64_decode(base64_decode($_COOKIE["cookiex"]))));
		
        if ($val->type == 'admin') {
			echo "<h1 ";
			
			echo $_COOKIE["passadmin"];
			if (strcmp($_COOKIE["passadmin"], $pass) == 0) {
				echo " class='right'>";
				echo "iki loh flag e :<br>CTF{merdeka_17081945}";
			} else {
				echo " class='wrong'>";
				echo "Password Admin masih Salah<br>";
			}
			
			echo "</h1";
		}
    }
?>
</h1>

